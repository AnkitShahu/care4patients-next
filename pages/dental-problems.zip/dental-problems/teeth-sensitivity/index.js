import React from 'react'

const TeethSensitivity = () => {
  return (
    <div>index</div>
  )
}

export default TeethSensitivity