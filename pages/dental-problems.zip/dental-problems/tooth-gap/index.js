import React from 'react'

const ToothGap = () => {
  return (
    <div>ToothGap</div>
  )
}

export default ToothGap